Eric Griffin's Personal Site:

This is my first major website project. It is a mock portfolio page.

The webpage consists of a Homepage with a persistent navigation bar that links to an About page and a Portfolio page.

Each page has a persistent footer than contains a button that causes the "Hello World" alter pop-up when clicked.

The Home page features a central box with a brief description, a quote, and a picture.

The About page contains blurbs about other activities I like and some images to accompany them.

The Portfolio page has a few images of freelance graphic design projects I did and brief description of each.

I built each page in HTML, each having it's own .html file. I used a single .css file to style each page, and I linked it to each html document.

I have one JavaScript file that contains script for the button function.
